function display()
{
	var a=document.getElementById("num1").value;
	var b=document.getElementById("num2").value;
	if(a=="admin" && b=="admin")
	{
	document.getElementById('result1').innerHTML="login successful";
	document.getElementById('result2').innerHTML="login successful";
	}
	else
	{
	document.getElementById('result1').innerHTML="Please enter a valid email address or phone number.";
	document.getElementById('result2').innerHTML="Your password must contain between 4 and 60 characters.";
	}
}